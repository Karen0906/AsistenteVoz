import time
import os

time.sleep(1)
os.remove('stream.wav')